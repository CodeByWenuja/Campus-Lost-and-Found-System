module.exports = {
  swDest: "public/sw.js",
  swSrc: "src/sw.js",
};
